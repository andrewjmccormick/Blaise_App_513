﻿using System;

public class Record
{
	public Record()
	{
	}
}
